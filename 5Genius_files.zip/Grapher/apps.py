from django.apps import AppConfig


class GrapherConfig(AppConfig):
    name = 'Grapher'
